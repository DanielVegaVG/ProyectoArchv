<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>EnviarAgradecimiento</title>
</head>
<main>
<header>
    <h1><span class="">A</span>GRADECE <span>EN</span> COMPAÑÍA</h1>
</header>
<body>
    <form action="get">
    <select>
        <!--<php?-->

        <!--Se hará un while con una variable que recoga la cantidad de filas que tiene la tabla alumno,creando un option por alumno-->
        <option value="1">nombrealumno</option>
        <!--El "value" será el idAlumno que recogemos de la base de datos
        y el "nombrealumno" se autocompletará automaticamente según el id de ese alumno-->
    </select>
    <textarea></textarea>
    </form>
</body>
</main>
</html>